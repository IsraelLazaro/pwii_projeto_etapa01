import { Colors } from "../constants/Colors";
export type AllColorKeys = keyof typeof Colors.light;